package com.example;

public class UserAuthentication {
	
		
		
	
	public String authenticate_login(String username, String password)
	{
		
		if((username.equals("Priya"))&&(password.equals("riya@21")))
		{
			return "Login Successfull";
		}
		else {
			return "Invalid";	
		}
		
		
		

	}
	}


