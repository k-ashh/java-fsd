package com.example;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class UserTest1 {

	UserAuthentication auth;
	@BeforeEach
	public void objectcreate() {
		auth=new UserAuthentication();
		System.out.println("Authentication object created");
	}
	@Test
	public void testcase1()
	
	{
		Assertions.assertEquals("Login Successfull", auth.authenticate_login("Priya","riya@21"));
		System.out.println("TestCase1");
		
	}
	@DisplayName("Test method2 with condition")
	@Test
	public void testcase2()
	{
		Assertions.assertEquals("Invalid", auth.authenticate_login("riya","riya@S21"));
		System.out.println("TestCase2");
		
	}
	@Test
	public void testcase3()
	{
		Assertions.assertEquals("Invalid", auth.authenticate_login("","riya@S21"));
		System.out.println("TestCase3");
		
	}
	@Test
	public void testcase4()
	{
		Assertions.assertEquals("Invalid", auth.authenticate_login("",""));
		System.out.println("TestCase4");
		
	}
	@Disabled
	public void testcase5()
	{
		Assertions.assertEquals("Invalid", auth.authenticate_login("Priya",""));
		System.out.println("TestCase5");
		
	}
	
	@AfterEach
	public void objectremove() {
		auth=null;
		System.out.println("object is removed");
	}


}
