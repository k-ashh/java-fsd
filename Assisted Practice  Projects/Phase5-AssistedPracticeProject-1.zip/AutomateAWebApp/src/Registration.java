import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Sleeper;

public class Registration {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\95\\chromedriver.exe");
		WebDriver wd=new ChromeDriver();
		wd.manage().window().maximize();
		Thread.sleep(2000);
		wd.get("https://www.amazon.com/");
		Thread.sleep(2000);
	    wd.findElement(By.linkText("Start here.")).click();
	    Thread.sleep(2000);
		wd.findElement(By.xpath("//*[@id=\"ap_customer_name\"]")).sendKeys("karthik");
		Thread.sleep(2000);
		wd.findElement(By.id("ap_email")).sendKeys("k@gmail.com");
		Thread.sleep(2000);
		wd.findElement(By.id("ap_password")).sendKeys("1234@c");
		Thread.sleep(2000);
		wd.findElement(By.id("ap_password_check")).sendKeys("1234@c");
		Thread.sleep(2000);
		wd.findElement(By.id("continue")).sendKeys(Keys.ENTER);
	    wd.close();
		
		  
		  
		  }

}
