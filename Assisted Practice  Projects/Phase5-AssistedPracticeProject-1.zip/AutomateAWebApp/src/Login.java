import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\95\\chromedriver.exe");
		WebDriver wd=new ChromeDriver();
		wd.manage().window().maximize();
		Thread.sleep(2000);
		wd.get("https://www.amazon.com/");
		Thread.sleep(2000);
	   wd.findElement(By.xpath("//*[@id=\"nav-link-accountList\"]/span")).click();
	   Thread.sleep(2000);
	   wd.findElement(By.id("ap_email")).sendKeys("k@gmail.com");
	   Thread.sleep(2000);
	   wd.findElement(By.id("continue")).click();
	   Thread.sleep(2000);
	   wd.findElement(By.id("ap_password")).sendKeys("1234@c");
	   Thread.sleep(2000);
	   wd.findElement(By.id("signInSubmit")).submit();
	   wd.close();
	   
	}

}
