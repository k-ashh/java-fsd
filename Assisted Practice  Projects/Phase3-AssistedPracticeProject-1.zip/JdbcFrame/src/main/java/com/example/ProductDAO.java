package com.example;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

public class ProductDAO {
	private JdbcTemplate temp;

	public void setTemp(JdbcTemplate temp) {
		this.temp = temp;
	}
	public int insert(Product p) {
		String sql="insert into product values("+p.getPid()+",'"+p.getPname()+"',"+p.getPcost()+","+p.getPquan()+")";
		System.out.println(sql);
		return temp.update(sql);
		
	}
	/*Retrival-select-Resultset(executeQuery)*/
	public List<Product> getAll(){
		String sql="select * from product";
		return temp.query(sql,new ResultSetExtractor<List<Product>>() {

			public List<Product> extractData(ResultSet rs) throws SQLException, DataAccessException {
				ArrayList<Product> al=new ArrayList<Product>();
				while(rs.next()){
					Product p=new Product();
					p.setPid(rs.getInt(1));
					p.setPname(rs.getString(2));
					
					p.setPcost(rs.getInt(3));
					p.setPquan(rs.getInt(4));
					al.add(p);
				}
				return al;
				
			}
			
		});

}
}
