package com.example;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProductController {
	@RequestMapping("/insert")
	public ModelAndView insert(HttpServletRequest req,HttpServletResponse res) {
		ModelAndView mv=new ModelAndView();
		ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
        Product p=ac.getBean(Product.class);
        p.setPid(Integer.parseInt(req.getParameter("id")));
		p.setPname(req.getParameter("name"));
		
		 p.setPcost(Integer.parseInt(req.getParameter("cost")));
		 p.setPquan(Integer.parseInt(req.getParameter("no")));
		 ProductDAO dao=ac.getBean(ProductDAO.class);
		System.out.println(dao);
		
		int row=dao.insert(p);
		
		if(row>0) {
			mv.setViewName("display.jsp");
		}
		return mv;
	}
	
	
	@RequestMapping("/getall")
	public ModelAndView getall(HttpServletRequest req,HttpServletResponse res) {
		ModelAndView mv=new ModelAndView();
		ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		Product p=ac.getBean(Product.class);
		ProductDAO dao=ac.getBean(ProductDAO.class);
		List<Product> stu=dao.getAll();
		mv.setViewName("displayall.jsp");
		mv.addObject("prod", stu);
		return mv;
	}
	


}



